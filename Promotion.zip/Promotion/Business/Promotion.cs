﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Promotion
    {
        public string SKUName { get; set; }
        public decimal UnitPrice { get; set; }
        public int PromotionQty { get; set; }
        public int PromotionPrice { get; set; }
        public string LinkedSKUName { get; set; }
        public decimal FixedLinkedPrice { get; set; }
        public bool ShowLinkedPrice { get; set; }
    }
}
