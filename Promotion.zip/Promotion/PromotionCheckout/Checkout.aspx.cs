﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business;

namespace PromotionCheckout
{
    public partial class Checkout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                Utility util = new Utility();
                List<Promotion> promotionList = util.GetPromotionList();
        
                gvItems.DataSource = promotionList;
                gvItems.DataBind();
                gvItems.ShowFooter = true;
            }
        }

        public void chkSKU_CheckChanged(object sender, EventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            TextBox txt = (TextBox)chk.Parent.Parent.FindControl("txtQty");
            Label lbl = (Label)chk.Parent.Parent.FindControl("lblPrice");
            var gridRow = (GridViewRow)chk.Parent.Parent;
            var skuName = gridRow.Cells[1].Text;
            if (chk.Checked)
            {
                txt.Enabled = true;
            }
            else
            {
                txt.Enabled = false;
                txt.Text = "";
            }
            CalculatePrice(gridRow.RowIndex, skuName);
        }

        public void txtQty_TextChanged(object sender, EventArgs e)
        {
            TextBox txt = (TextBox)sender;
            var gridRow = (GridViewRow)txt.Parent.Parent;
            var skuName = gridRow.Cells[1].Text;
            CalculatePrice(gridRow.RowIndex, skuName);
        }

        private void CalculatePrice(int rowIndex, string skuName)
        {
            Utility util = new Utility();
            List<Promotion> promotionList = util.GetPromotionList();
        
            Promotion promotion = promotionList.SingleOrDefault(p => p.SKUName == skuName);
            Label lblPrice = (Label)gvItems.Rows[rowIndex].FindControl("lblPrice");
            TextBox txtQty = (TextBox)gvItems.Rows[rowIndex].FindControl("txtQty");
            var enteredQty = Convert.ToInt32(txtQty.Text.Length > 0 ? txtQty.Text : "0");
            var unitPrice = promotion.UnitPrice;
            var setQty = promotion.PromotionQty;
            var setPrice = promotion.PromotionPrice;
            var fixedSetPrice = promotion.FixedLinkedPrice;
            var showLinkedPrice = promotion.ShowLinkedPrice;

            if (promotion.LinkedSKUName != null && promotion.LinkedSKUName.Length > 0)
            {
                var linkedRowIndex = -1;
                for (int c = 0; c < gvItems.Rows.Count; ++c)
                {
                    if (promotion.LinkedSKUName == gvItems.Rows[c].Cells[1].Text)
                    {
                        linkedRowIndex = c;
                        break;
                    }
                }  
                
                Promotion linkedPromotion = promotionList.SingleOrDefault(p => p.SKUName == promotion.LinkedSKUName);
                Label linkedLblPrice = (Label)gvItems.Rows[linkedRowIndex].FindControl("lblPrice");
                TextBox txtLinkedQty = (TextBox)gvItems.Rows[linkedRowIndex].FindControl("txtQty");
                var linkedSKUEnteredQty = Convert.ToInt32(txtLinkedQty.Text.Length > 0 ? txtLinkedQty.Text : "0");
                var showLinkedPrice2 = linkedPromotion.ShowLinkedPrice;
                if (enteredQty > 0)
                {
                    if (linkedSKUEnteredQty == 0)
                    {
                        lblPrice.Text = (enteredQty * unitPrice).ToString();
                    }
                    else if (enteredQty == linkedSKUEnteredQty)
                    {
                        if (showLinkedPrice)
                        {
                            lblPrice.Text = (enteredQty * fixedSetPrice).ToString();
                            linkedLblPrice.Text = "";
                        }
                        else
                        {
                            linkedLblPrice.Text = (enteredQty * fixedSetPrice).ToString();
                            lblPrice.Text = "";
                        }
                    }
                    else
                    {
                        if (enteredQty > linkedSKUEnteredQty)
                        {
                            if (showLinkedPrice)
                            {
                                lblPrice.Text = ((linkedSKUEnteredQty * fixedSetPrice) + (unitPrice * (enteredQty - linkedSKUEnteredQty))).ToString();
                                linkedLblPrice.Text = "";
                            }
                            else
                            {
                                linkedLblPrice.Text = (linkedSKUEnteredQty * fixedSetPrice).ToString();
                                lblPrice.Text = (unitPrice * (enteredQty - linkedSKUEnteredQty)).ToString();
                            }
                        }
                        else
                        {
                            if (showLinkedPrice)
                            {
                                lblPrice.Text = (enteredQty * fixedSetPrice).ToString();
                                linkedLblPrice.Text = (unitPrice * (linkedSKUEnteredQty - enteredQty)).ToString();
                            }
                            else
                            {
                                linkedLblPrice.Text = ((enteredQty * fixedSetPrice) + (unitPrice * (linkedSKUEnteredQty - enteredQty))).ToString();
                                lblPrice.Text = "";
                            }
                        }
                    }
                }
            }
            else if (setQty > 0)
            {
                if (enteredQty >= setQty)
                {
                    lblPrice.Text = ((setPrice * (enteredQty / setQty)) + (unitPrice * (enteredQty % setQty))).ToString();
                }
                else
                {
                    lblPrice.Text = (unitPrice * (enteredQty % setQty)).ToString();
                }
            }
            CalculateTotalPrice();
        }

        private void CalculateTotalPrice()
        {
            decimal totalPrice = 0;

            for (int c = 0; c < gvItems.Rows.Count; ++c)
            {
                Label lblPrice = (Label)gvItems.Rows[c].FindControl("lblPrice");
                decimal price = Convert.ToDecimal(lblPrice.Text != "" ? lblPrice.Text : "0");
                totalPrice += price;
            }

            Label lblTotalPrice = (Label)gvItems.FooterRow.FindControl("lblTotalPrice");
            lblTotalPrice.Text = totalPrice.ToString();
        }
        
    }
}