﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Utility
    {
        public string Name { get; set; }
        
        public Utility()
        {
            this.Name = "From Utility Class";
        }

        public List<Promotion> GetPromotionList()
        {
            List<Promotion> promotionList = new List<Promotion>();

            var promotion = new Promotion();
            promotion.SKUName = "A";
            promotion.UnitPrice = 50;
            promotion.PromotionQty = 3;
            promotion.PromotionPrice = 130;
            promotionList.Add(promotion);

            promotion = new Promotion();
            promotion.SKUName = "B";
            promotion.UnitPrice = 30;
            promotion.PromotionQty = 2;
            promotion.PromotionPrice = 45;
            promotionList.Add(promotion);

            promotion = new Promotion();
            promotion.SKUName = "C";
            promotion.UnitPrice = 20;
            promotion.PromotionQty = 0;
            promotion.PromotionPrice = 0;
            promotion.LinkedSKUName = "D";
            promotion.FixedLinkedPrice = 30;
            promotionList.Add(promotion);

            promotion = new Promotion();
            promotion.SKUName = "D";
            promotion.UnitPrice = 15;
            promotion.PromotionQty = 0;
            promotion.PromotionPrice = 0;
            promotion.LinkedSKUName = "C";
            promotion.FixedLinkedPrice = 30;
            promotion.ShowLinkedPrice = true;
            promotionList.Add(promotion);

            return promotionList;
        }
    }
}
